define({
  TOGGLE: 'sample_app_showhide',
});