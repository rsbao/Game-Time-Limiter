define([
  '../SampleAppView.js'
], function (SampleAppView) {

  class DesktopView extends SampleAppView {
    constructor() {
      super();
    }
  }

  return DesktopView;
});